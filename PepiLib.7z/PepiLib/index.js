const libs = require('./calculator/calculator')
const Library = require('./libraryClass')
const NumericSystems = libs.NumericSystems
const PhysicsUnits = libs.PhysicsUnits
const Computer = require('./computer').Computer
const ProgramsAndUser=require('./computer').ProgramsAndUser
const Err=require('./error')
const Forum=require('./forum')
const MathClassesAndFuncs=require('./math')
console.log(MathClassesAndFuncs.calculator.evaluate('x+1+x*x+x*2',{constants:{
x:1
}}))
const calculator=MathClassesAndFuncs.calculator
const Complex=MathClassesAndFuncs.Complex
const algebraSet=require('./algebra.js')

const libraries={}
libraries['algebraSet']=algebraSet
libraries['Library']=Library
libraries['NumericSystems']=NumericSystems
libraries['PhysicsUnits']=PhysicsUnits
libraries['Computer']=Computer
libraries['ProgramsAndUser']=ProgramsAndUser
libraries['Err']=Err
libraries['Forum']=Forum
libraries['MathClassesAndFuncs']=MathClassesAndFuncs.MathClassesAndFuncs
libraries['Complex']=Complex
libraries['Calculator']=calculator
module.exports=libraries